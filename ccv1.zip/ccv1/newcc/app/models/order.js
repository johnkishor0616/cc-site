var mongoose = require('mongoose');
//schema to our host details
var hostSchema = mongoose.Schema({
    yourname:{type:String},
    homeaddress:{type:String},
    yourmobilenumber:{type:String},
    yourprogramname:{type:String},
    date:{type:String},



});


module.exports = mongoose.model('order', hostSchema);
